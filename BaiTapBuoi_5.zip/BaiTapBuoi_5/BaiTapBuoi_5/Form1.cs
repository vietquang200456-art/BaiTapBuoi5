﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiTapBuoi_5
{
    public partial class FSoanThao : Form
    {
        public FSoanThao()
        {
            InitializeComponent();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                control.Left = (this.ClientSize.Width - control.Width) / 2;
                control.Top = (this.ClientSize.Height - control.Height) / 2;
            }
        }
        private string CurrentFilePath = string.Empty;
        private bool isModified = false;
        private bool CheckSave()
        {
            if (isModified)
            {
                DialogResult r = MessageBox.Show("Bạn có muốn lưu lại không?", "Lưu",
                    MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Question);
                if (r == DialogResult.Yes)
                {
                    SaveFile();
                    return true;
                }
                else if (r == DialogResult.No)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            return true;
        }
        private void SaveFile()
        {
            if (!string.IsNullOrEmpty(CurrentFilePath))
            {
                if (CurrentFilePath.EndsWith(".rtf"))
                {
                    rtbSoanThao.SaveFile(CurrentFilePath);
                }
                else
                {
                    rtbSoanThao.SaveFile(CurrentFilePath, RichTextBoxStreamType.PlainText);
                }
                isModified = false;
            }
            else
            {
                SaveFileAs();
            }
        }
        private void SaveFileAs()
        {

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Rich Text Format|*.rtf|Text Files|*.txt|All Files|*.*";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                CurrentFilePath = sfd.FileName;
                if (CurrentFilePath.EndsWith(".rtf"))
                {
                    rtbSoanThao.SaveFile(CurrentFilePath);
                }
                else
                {
                    rtbSoanThao.SaveFile(CurrentFilePath, RichTextBoxStreamType.PlainText);
                }
                isModified = false;
            }
        }
        private void rtbSoanThao_TextChanged(object sender, EventArgs e)
        {
            isModified = true;
            string[] strings = rtbSoanThao.Text.Split(new char[] { ' ', '\n', '\r' },
                StringSplitOptions.RemoveEmptyEntries);
            tlbDemTu.Text = "Tổng số chữ : " + strings.Length;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            tscbFont.Text = "Tahoma";
            tscbSize.Text = "14";

            foreach (FontFamily font in FontFamily.Families)
            {
                tscbFont.Items.Add(font.Name);
            }
            for (int i = 8; i < 72; i += 2)
            {
                tscbSize.Items.Add(i);
            }

            rtbSoanThao.Font = new Font("Tahoma", 14);
            tlbDemTu.Text = "Tổng số chữ : 0";
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!CheckSave())
            {
                e.Cancel = true;
            }
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void menuNew_Click(object sender, EventArgs e)
        {
            if (CheckSave())
            {
                rtbSoanThao.Clear();
                CurrentFilePath = string.Empty;
                rtbSoanThao.Font = new Font("Tahoma", 14);
                tscbFont.Text = "Tahoma";
                tscbSize.Text = "14";
                isModified = false;
            }
        }

        private void menuOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Rich Text Format|*.rtf|Text Files|*.txt|All Files|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                CurrentFilePath = ofd.FileName;
                if (CurrentFilePath.EndsWith(".rtf"))
                {
                    rtbSoanThao.LoadFile(CurrentFilePath, RichTextBoxStreamType.RichText);
                }
                else
                {
                    rtbSoanThao.LoadFile(CurrentFilePath, RichTextBoxStreamType.PlainText);
                }
            }
        }

        private void menuSave_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void menuSaveas_Click(object sender, EventArgs e)
        {
            SaveFileAs();
        }

        private void tscbFont_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fontName = tscbFont.Text;
            if (rtbSoanThao.SelectionFont != null)
            {
                Font currentFont = rtbSoanThao.SelectionFont;
                rtbSoanThao.SelectionFont = new Font(fontName, currentFont.Size, currentFont.Style);
            }
        }

        private void tscbSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (float.TryParse(tscbSize.Text, out float Size))
            {
                if (rtbSoanThao.SelectionFont != null)
                {
                    Font currentFont = rtbSoanThao.SelectionFont;
                    rtbSoanThao.SelectionFont = new Font(currentFont.FontFamily, Size, currentFont.Style);
                }
            }
        }

        private void tsbtnNew_Click(object sender, EventArgs e)
        {
            menuNew_Click(sender, e);
        }

        private void tsbtnSave_Click(object sender, EventArgs e)
        {
            menuSave_Click(sender, e);
        }

        private void tsbtnSaveAs_Click(object sender, EventArgs e)
        {
            menuSaveas_Click
                (sender, e);
        }

    
        private void menuDinhDang_Click(object sender, EventArgs e)
        {
            FontDialog fontDlg = new FontDialog();
            fontDlg.ShowColor = true;
            fontDlg.ShowApply = true;
            fontDlg.ShowEffects = true;
            fontDlg.ShowHelp = true;
            if (fontDlg.ShowDialog() != DialogResult.Cancel)
            {
                rtbSoanThao.ForeColor = fontDlg.Color;
                rtbSoanThao.Font = fontDlg.Font;
            }
        }
        private void tsbtnBold_Click(object sender, EventArgs e)
        {

            if (rtbSoanThao.SelectionFont != null)
            {
                Font currentFont = rtbSoanThao.SelectionFont;
                FontStyle newStyle = currentFont.Style ^ FontStyle.Bold;
                rtbSoanThao.SelectionFont = new Font(currentFont, newStyle);
                tsbtnBold.Checked = rtbSoanThao.SelectionFont.Bold;
            }
        }

        private void tsbtnItalic_Click(object sender, EventArgs e)
        {
            if (rtbSoanThao.SelectionFont != null)
            {
                Font currentFont = rtbSoanThao.SelectionFont;
                FontStyle newStyle = currentFont.Style ^ FontStyle.Italic;
                rtbSoanThao.SelectionFont = new Font(currentFont, newStyle);
                tsbtnItalic.Checked = rtbSoanThao.SelectionFont.Italic;
            }
        }

        private void tsbtnUnderline_Click(object sender, EventArgs e)
        {
            if(rtbSoanThao.SelectionFont != null)
            {
                Font currentFont = rtbSoanThao.SelectionFont;
                FontStyle newStyle = currentFont.Style ^ FontStyle.Underline;
                rtbSoanThao.SelectionFont = new Font(currentFont, newStyle);
                tsbtnUnderline.Checked = rtbSoanThao.SelectionFont.Underline;
            }
        }

    }
}
